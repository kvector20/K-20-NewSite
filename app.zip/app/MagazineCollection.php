<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MagazineCollection extends Model
{
    //
}
