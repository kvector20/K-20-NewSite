<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MagazineCollection;
use Faker\Generator as Faker;

$factory->define(MagazineCollection::class, function (Faker $faker) {
    return [
        'magazine_id' => function () {
            return factory(App\Magazine::class)->create()->id;
        },
        'collection_name' => $faker->text(10),
        'collection_month' => $faker->text(10),
    ];
});
