import React, { Component } from 'react';
import ReactDOM from 'react-dom';

export default class Example extends Component {
    render() {
        return (
            <div className="container h-100">
                <div className="row justify-content-center align-items-center h-100">
                    <div className="col-md-8 mx-auto">
                        <h1 className='text-center'>We Are Coming Soon</h1>
                    </div>
                </div>
            </div>
        );
    }
}

if (document.getElementById('example')) {
    ReactDOM.render(<Example />, document.getElementById('example'));
}
